//
//  ViewController.swift
//  OceanLife
//
//  Created by syan k on 2024/6/14.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func FishClicked(_ sender: Any) {
        print("Fish")
        titleLabel.text = "Clown Fish"
    }
    
    @IBAction func TurtleClicked(_ sender: Any) {
        print("Turtle")
        titleLabel.text = "Sea Turtle"
    }
    
    @IBAction func DolphinClicked(_ sender: Any) {
        print("Dolphin")
        titleLabel.text = "Dolphin"
    }
    
    @IBAction func CrabClicked(_ sender: Any) {
        print("Crab")
        titleLabel.text = "Crab"
    }
    
    @IBAction func OtterClicked(_ sender: Any) {
        print("Otter")
        titleLabel.text = "Sea Otter"
    }
    
    @IBAction func OctopusClicked(_ sender: Any) {
        print("Octopus")
        titleLabel.text = "Octopus"
    }
}

