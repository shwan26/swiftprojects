//
//  ViewController.swift
//  SimpleFormInput
//
//  Created by syan k on 2024/6/14.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    
    @IBOutlet weak var firstname: UITextField!
    @IBOutlet weak var lastname: UITextField!
    @IBOutlet weak var age: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    @IBAction func buttonClicked(_ sender: Any) {
        nameLabel.text = "Your name is \(firstname.text!) \(lastname.text!)."
        ageLabel.text = "You are \(age.text!) years old."
    }
    

}

